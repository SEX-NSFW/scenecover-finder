const I18N = {
  ar: {
    tagline: "من الاسم إلى الغلاف الرسمي",
    placeholder: "اكتب اسم المشهد أو Family Strokes...",
    search: "بحث",
    stage1: "قراءة الاستعلام",
    stage2: "فتح صفحة Family Strokes",
    stage3: "استخراج og:image",
    stage4: "التحقق من الغلاف الترويجي",
    copy: "نسخ",
    download: "فتح",
    history: "عمليات البحث الأخيرة",
    footer: "أصل · Grok project · أغلفة ترويجية رسمية · 18+",
    noCover: "لم يتم العثور على غلاف ترويجي رسمي.",
    studio: "الاستوديو",
    realTitle: "العنوان الرسمي",
    performers: "الممثلون",
    summary: "الملخص",
    officialLink: "الرابط الرسمي",
    confidence: "الثقة",
    high: "عالية",
    medium: "متوسطة",
    low: "منخفضة",
    copied: "تم النسخ!",
    errorGeneric: "فشل البحث. تأكد أن السيرفر يعمل (python3 server.py).",
    refuseMinor: "مرفوض: محتوى يشير إلى قاصر.",
    example1: "Prom Night Pussy Practice",
    example2: "Family Vacation!!! Family Strokes",
    example3: "It Just Slipped In S2:E8 Bratty Sis",
  },
  en: {
    tagline: "From name to official cover",
    placeholder: "Scene name or Family Strokes title...",
    search: "Search",
    stage1: "Reading query",
    stage2: "Opening Family Strokes page",
    stage3: "Extracting og:image",
    stage4: "Verifying promotional cover",
    copy: "Copy",
    download: "Open",
    history: "Recent searches",
    footer: "Asl · Grok project · Official promotional covers · 18+",
    noCover: "No official promotional cover found.",
    studio: "Studio",
    realTitle: "Official title",
    performers: "Performers",
    summary: "Summary",
    officialLink: "Official link",
    confidence: "Confidence",
    high: "High",
    medium: "Medium",
    low: "Low",
    copied: "Copied!",
    errorGeneric: "Search failed. Is the server running? (python3 server.py)",
    refuseMinor: "Refused: possible minor content.",
    example1: "Prom Night Pussy Practice",
    example2: "Family Vacation!!! Family Strokes",
    example3: "It Just Slipped In S2:E8 Bratty Sis",
  },
};

const LANGS = [
  { code: "ar", label: "العربية" },
  { code: "en", label: "English" },
];
const RTL = new Set(["ar"]);
let lang = localStorage.getItem("asl_lang") || "ar";

function t(key) {
  return (I18N[lang] && I18N[lang][key]) || I18N.en[key] || key;
}

function applyLang() {
  document.documentElement.lang = lang;
  document.documentElement.dir = RTL.has(lang) ? "rtl" : "ltr";
  document.body.classList.toggle("rtl", RTL.has(lang));
  document.querySelectorAll("[data-i18n]").forEach((el) => {
    el.textContent = t(el.dataset.i18n);
  });
  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
    el.placeholder = t(el.dataset.i18nPlaceholder);
  });
  const bar = document.getElementById("lang-bar");
  bar.innerHTML = "";
  LANGS.forEach((l) => {
    const b = document.createElement("button");
    b.className = "lang-btn" + (l.code === lang ? " active" : "");
    b.textContent = l.label;
    b.onclick = () => {
      lang = l.code;
      localStorage.setItem("asl_lang", lang);
      applyLang();
      renderExamples();
    };
    bar.appendChild(b);
  });
  renderExamples();
}

function renderExamples() {
  const el = document.getElementById("examples");
  el.innerHTML = "";
  [t("example1"), t("example2"), t("example3")].forEach((txt) => {
    const c = document.createElement("button");
    c.className = "chip";
    c.textContent = txt;
    c.onclick = () => {
      document.getElementById("q").value = txt;
      doSearch();
    };
    el.appendChild(c);
  });
}

function setStage(n) {
  document.querySelectorAll(".stage").forEach((s) => {
    const sn = +s.dataset.stage;
    s.classList.remove("active", "done");
    if (sn < n) s.classList.add("done");
    if (sn === n) s.classList.add("active");
  });
}

function showStages(show) {
  document.getElementById("stages").classList.toggle("show", show);
}

function hideResults() {
  document.getElementById("result").classList.remove("show");
  document.getElementById("error-box").classList.remove("show");
  document.getElementById("empty-box").classList.remove("show");
}

function saveHistory(q) {
  let hist = JSON.parse(localStorage.getItem("asl_hist") || "[]");
  hist = hist.filter((x) => x !== q);
  hist.unshift(q);
  hist = hist.slice(0, 8);
  localStorage.setItem("asl_hist", JSON.stringify(hist));
  renderHistory();
}

function renderHistory() {
  const hist = JSON.parse(localStorage.getItem("asl_hist") || "[]");
  const wrap = document.getElementById("history-wrap");
  const list = document.getElementById("history-list");
  if (!hist.length) {
    wrap.style.display = "none";
    return;
  }
  wrap.style.display = "block";
  list.innerHTML = "";
  hist.forEach((q) => {
    const d = document.createElement("div");
    d.className = "hist-item";
    d.textContent = q;
    d.onclick = () => {
      document.getElementById("q").value = q;
      doSearch();
    };
    list.appendChild(d);
  });
}

function renderReport(data) {
  const rows = [
    [t("studio"), data.studio || "—"],
    [t("realTitle"), data.originalTitle || "—"],
    [t("performers"), (data.performers || []).join(", ") || "—"],
    [
      t("officialLink"),
      data.officialUrl
        ? `<a href="${data.officialUrl}" target="_blank" rel="noopener" style="color:var(--accent)">${data.officialUrl}</a>`
        : "—",
    ],
    [t("confidence"), t(data.confidence || "low")],
  ];
  let html = `<h3>${t("realTitle")}</h3>`;
  rows.forEach(([lab, val]) => {
    html += `<div class="report-row"><div class="report-label">${lab}</div><div class="report-value">${val}</div></div>`;
  });
  if (data.officialSummary) {
    html += `<div class="report-label" style="margin-top:0.75rem">${t("summary")}</div>`;
    html += `<div class="summary-box">${data.officialSummary}</div>`;
  }
  if (data.notes) {
    html += `<div class="report-row" style="margin-top:0.5rem"><div class="report-label">Notes</div><div class="report-value" style="color:var(--muted);font-size:0.85rem">${data.notes}</div></div>`;
  }
  document.getElementById("report").innerHTML = html;
}

async function doSearch() {
  const q = document.getElementById("q").value.trim();
  if (!q) return;

  if (/\b(teen\s*1[0-7]|underage|child|loli|shota)\b/i.test(q)) {
    hideResults();
    document.getElementById("error-msg").textContent = t("refuseMinor");
    document.getElementById("error-box").classList.add("show");
    return;
  }

  hideResults();
  showStages(true);
  document.getElementById("search-btn").disabled = true;
  for (let i = 1; i <= 4; i++) {
    setStage(i);
    await new Promise((r) => setTimeout(r, 280));
  }

  try {
    const res = await fetch("/api/search?q=" + encodeURIComponent(q));
    if (!res.ok) throw new Error("HTTP " + res.status);
    const data = await res.json();
    if (data.error) throw new Error(data.error);

    showStages(false);
    document.getElementById("search-btn").disabled = false;
    saveHistory(q);

    if (!data.coverUrl) {
      document.getElementById("empty-box").classList.add("show");
      const ul = document.getElementById("empty-sources");
      ul.innerHTML = "";
      (data.sourcesTried || []).slice(0, 8).forEach((s) => {
        const li = document.createElement("li");
        li.textContent = (s.via || "") + " · " + (s.url || "");
        ul.appendChild(li);
      });
      return;
    }

    const img = document.getElementById("cover-img");
    img.src = data.coverUrl;
    img.onclick = () => window.open(data.coverUrl, "_blank");
    document.getElementById("cover-url").value = data.coverUrl;
    document.getElementById("dl-btn").href = data.coverUrl;

    const badge = document.getElementById("conf-badge");
    badge.textContent = t(data.confidence || "low");
    badge.className = "confidence conf-" + (data.confidence || "low");

    renderReport(data);
    document.getElementById("result").classList.add("show");
  } catch (e) {
    showStages(false);
    document.getElementById("search-btn").disabled = false;
    document.getElementById("error-msg").textContent =
      t("errorGeneric") + " " + (e.message || "");
    document.getElementById("error-box").classList.add("show");
  }
}

document.getElementById("search-btn").onclick = doSearch;
document.getElementById("q").addEventListener("keydown", (e) => {
  if (e.key === "Enter") doSearch();
});
document.getElementById("copy-btn").onclick = () => {
  const url = document.getElementById("cover-url").value;
  navigator.clipboard.writeText(url).then(() => {
    const btn = document.getElementById("copy-btn");
    const old = btn.textContent;
    btn.textContent = t("copied");
    setTimeout(() => (btn.textContent = old), 1500);
  });
};

document.getElementById("q").value = "Prom Night Pussy Practice";
applyLang();
renderHistory();
