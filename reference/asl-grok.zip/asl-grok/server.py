#!/usr/bin/env python3
"""
أصل (Asl) — Grok project
من الاسم إلى الغلاف الرسمي | Family Strokes / TeamSkeet first
"""
from __future__ import annotations

import json
import re
import ssl
from concurrent.futures import ThreadPoolExecutor, as_completed
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, unquote, urlparse
from urllib.request import Request, urlopen

try:
    import requests
    from bs4 import BeautifulSoup

    HAS_BS4 = True
except ImportError:
    HAS_BS4 = False

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)
TIMEOUT = 10
PORT = 8765


def normalize(q: str) -> str:
    return re.sub(r"\s+", " ", unquote(q or "").strip())


def clean_title(q: str) -> str:
    t = q.lower()
    t = re.sub(r"\bs\d{1,2}\s*[:\-]?\s*e\d{1,2}\b", " ", t, flags=re.I)
    t = re.sub(r"\b(season|episode|ep)\s*\d+\b", " ", t, flags=re.I)
    for s in (
        "family strokes",
        "familystrokes",
        "bratty sis",
        "brattysis",
        "moms teach sex",
        "momsteachsex",
        "sis loves me",
        "sislovesme",
        "dad crush",
        "dadcrush",
        "pervmom",
        "perv mom",
        "teamskeet",
        "team skeet",
        "momishorny",
        "mom is horny",
        "nubiles",
        "nubile films",
    ):
        t = t.replace(s, " ")
    t = re.sub(r"[!?.¡¿]+", " ", t)
    t = re.sub(r"[^\w\s\-']", " ", t, flags=re.U)
    return re.sub(r"\s+", " ", t).strip(" -_")


def slug_hyphen(title: str) -> str:
    s = re.sub(r"[^a-z0-9\s]", "", title.lower())
    return re.sub(r"\s+", "-", s.strip())


def slug_underscore(title: str) -> str:
    s = re.sub(r"[^a-z0-9\s]", "", title.lower())
    return re.sub(r"\s+", "_", s.strip())


def detect_studios(q: str) -> list[str]:
    ql = q.lower()
    mapping = [
        ("family strokes", "fs"),
        ("familystrokes", "fs"),
        ("bratty sis", "bratty"),
        ("brattysis", "bratty"),
        ("moms teach sex", "mts"),
        ("momsteachsex", "mts"),
        ("sis loves me", "slm"),
        ("sislovesme", "slm"),
        ("dad crush", "dc"),
        ("dadcrush", "dc"),
        ("pervmom", "pvm"),
        ("perv mom", "pvm"),
        ("momishorny", "mih"),
        ("mom is horny", "mih"),
        ("teamskeet", "ts"),
        ("nubiles", "nubiles"),
        ("nubile", "nubiles"),
    ]
    found = [code for key, code in mapping if key in ql]
    if not found and any(
        w in ql
        for w in (
            "stepson",
            "stepsis",
            "stepsister",
            "stepbrother",
            "stepmom",
            "stepdad",
            "pussy",
            "milf",
            "creampie",
        )
    ):
        found = ["fs", "bratty", "mts", "slm", "dc", "pvm"]
    return list(dict.fromkeys(found))


def score_cover(url: str) -> int:
    if not url:
        return -999
    u = url.lower()
    score = 0
    if "samples/cover1280.jpg" in u and not re.search(r"cover1280-\d", u):
        score += 24
    if "images.psmcdn.net" in u and "/shared/hi.jpg" in u:
        score += 22
    if "images.psmcdn.net" in u and "/shared/med.jpg" in u:
        score += 18
    if "brattyfamily.com/wp-content/uploads" in u:
        score += 20
    if "familystrokes.com" in u or "teamskeet.com" in u:
        score += 12
    if re.search(r"\.(jpg|jpeg|png|webp)(\?|$)", u):
        score += 5
    if re.search(r"cover1280-\d", u):
        score -= 80
    if any(x in u for x in ("/photos/", "/gallery/", "/tn/", "/stills/", "/thumbs/", "/preview/")):
        score -= 80
    if any(x in u for x in ("favicon", "logo", "sprite", "avatar", "icon")):
        score -= 100
    return score


def fetch(url: str, method: str = "GET", timeout: int = TIMEOUT) -> tuple[int, bytes, str, str]:
    """status, body, content_type, final_url"""
    headers = {"User-Agent": UA, "Accept": "*/*"}
    try:
        if HAS_BS4 and method == "GET":
            r = requests.get(url, headers=headers, timeout=timeout, allow_redirects=True)
            return r.status_code, r.content, (r.headers.get("Content-Type") or ""), r.url
        req = Request(url, headers=headers, method=method)
        ctx = ssl.create_default_context()
        with urlopen(req, timeout=timeout, context=ctx) as resp:
            body = resp.read() if method != "HEAD" else b""
            return resp.status, body, (resp.headers.get("Content-Type") or ""), resp.geturl()
    except HTTPError as e:
        return e.code, b"", "", url
    except Exception:
        return 0, b"", "", url


def is_image_url(url: str) -> bool:
    status, body, ct, _ = fetch(url, method="HEAD", timeout=6)
    if status == 200 and ct.lower().startswith("image/"):
        return True
    status, body, ct, _ = fetch(url, method="GET", timeout=8)
    if status not in (200, 206):
        return False
    if ct.lower().startswith("image/"):
        return True
    if body[:3] == b"\xff\xd8" or body[:8].startswith(b"\x89PNG") or b"WEBP" in body[:16]:
        return True
    return False


def extract_og(html: str) -> dict:
    out = {"og_image": None, "title": None, "description": None, "performers": []}
    if not html:
        return out
    if HAS_BS4:
        soup = BeautifulSoup(html, "html.parser")
        og = soup.find("meta", property="og:image") or soup.find(
            "meta", attrs={"property": "og:image"}
        )
        if og and og.get("content"):
            out["og_image"] = og["content"].strip()
        if not out["og_image"]:
            tw = soup.find("meta", attrs={"name": "twitter:image"})
            if tw and tw.get("content"):
                out["og_image"] = tw["content"].strip()
        t = soup.find("meta", property="og:title")
        if t and t.get("content"):
            out["title"] = t["content"].strip()
        elif soup.title and soup.title.string:
            out["title"] = soup.title.string.strip()
        d = soup.find("meta", property="og:description") or soup.find(
            "meta", attrs={"name": "description"}
        )
        if d and d.get("content"):
            out["description"] = d["content"].strip()
        for a in soup.select(
            '[class*="model"] a, [class*="performer"] a, [class*="cast"] a, .video-performers a'
        ):
            name = a.get_text(strip=True)
            if name and 1 < len(name) < 40 and name not in out["performers"]:
                out["performers"].append(name)
    else:
        m = re.search(
            r'property=["\']og:image["\'][^>]+content=["\']([^"\']+)', html, re.I
        ) or re.search(
            r'content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\']', html, re.I
        )
        if m:
            out["og_image"] = m.group(1).strip()
        m = re.search(r"<title[^>]*>([^<]+)</title>", html, re.I)
        if m:
            out["title"] = m.group(1).strip()
    return out


def identify(query: str) -> dict:
    q = normalize(query)
    result = {
        "studio": None,
        "series": None,
        "originalTitle": None,
        "performers": [],
        "categories": [],
        "officialSummary": None,
        "duration": None,
        "releaseDate": None,
        "officialUrl": None,
        "confidence": "low",
        "notes": "",
        "coverUrl": None,
        "coverScore": 0,
        "sourcesTried": [],
        "coverVerified": False,
    }
    if not q:
        result["notes"] = "Empty query"
        return result

    # Refuse minor-coded queries
    if re.search(r"\b(teen\s*1[0-7]|underage|child|loli|shota)\b", q, re.I):
        result["notes"] = "Refused: possible minor content"
        result["confidence"] = "low"
        return result

    title = clean_title(q) or q
    h = slug_hyphen(title)
    u = slug_underscore(title)
    studios = detect_studios(q)
    studio_names = {
        "fs": "Family Strokes",
        "bratty": "Bratty Sis",
        "mts": "Moms Teach Sex",
        "slm": "Sis Loves Me",
        "dc": "DadCrush",
        "pvm": "PervMom",
        "mih": "MomIsHorny",
        "nubiles": "Nubiles",
        "ts": "TeamSkeet",
    }
    if studios:
        result["studio"] = studio_names.get(studios[0], studios[0])
        result["series"] = result["studio"]
    else:
        result["studio"] = "Family Strokes"
        result["series"] = "Family Strokes"

    result["originalTitle"] = title.title() if title.islower() else title

    # --- Official pages (Family Strokes / TeamSkeet first) ---
    pages: list[str] = []
    if q.startswith("http://") or q.startswith("https://"):
        pages.append(q)
    pages += [
        f"https://www.familystrokes.com/movies/{h}",
        f"https://www.familystrokes.com/movies/{u.replace('_', '-')}",
        f"https://www.teamskeet.com/movies/{h}",
        f"https://www.sislovesme.com/movies/{h}",
        f"https://www.dadcrush.com/movies/{h}",
        f"https://www.pervmom.com/movies/{h}",
        f"https://brattyfamily.com/{h}/",
        f"https://momsteachsex.com/movies/{h}",
    ]
    pages = list(dict.fromkeys(pages))

    performers: list[str] = []
    for page in pages[:8]:
        status, body, _, final = fetch(page)
        result["sourcesTried"].append(
            {"url": page, "status": status, "via": "official page"}
        )
        if status != 200 or not body:
            continue
        html = body.decode("utf-8", errors="ignore")
        if len(html) < 500 and "join now" in html.lower():
            continue
        meta = extract_og(html)
        if meta.get("title"):
            t = re.sub(r"\s*[\|\-–].*$", "", meta["title"]).strip()
            if len(t) > 3:
                result["originalTitle"] = t
        if meta.get("description"):
            result["officialSummary"] = meta["description"][:600]
        if meta.get("performers"):
            performers = meta["performers"]
            result["performers"] = performers
        og = meta.get("og_image")
        if og and score_cover(og) >= 10:
            if not og.startswith("http"):
                og = final.rstrip("/") + "/" + og.lstrip("/")
            result["officialUrl"] = final
            # Prefer hi over med on psmcdn
            candidates = [og]
            if "/shared/med.jpg" in og:
                candidates.insert(0, og.replace("/shared/med.jpg", "/shared/hi.jpg"))
            for cand in candidates:
                sc = score_cover(cand)
                if sc >= 12 and is_image_url(cand):
                    result["coverUrl"] = cand
                    result["coverScore"] = sc
                    result["coverVerified"] = True
                    result["confidence"] = "high"
                    result["notes"] = "Official promotional cover from Family Strokes / TeamSkeet CDN"
                    result["sourcesTried"].append(
                        {"url": cand, "score": sc, "via": "og/CDN verified"}
                    )
                    return result
            # keep unverified og as last resort later
            if not result["coverUrl"]:
                result["coverUrl"] = og
                result["coverScore"] = score_cover(og)
                result["officialUrl"] = final

    # --- Direct CDN patterns ---
    codes = [c for c in studios if c in ("fs", "slm", "dc", "pvm", "mih", "ts")] or [
        "fs",
        "ts",
        "slm",
        "dc",
        "pvm",
    ]
    perf_slugs = [
        re.sub(r"[^a-z0-9]+", "_", p.lower()).strip("_") for p in performers[:3]
    ]
    slug_vars = list(dict.fromkeys([*perf_slugs, u, h.replace("-", "_")]))

    cdn_urls: list[str] = []
    for code in codes:
        for ps in slug_vars:
            cdn_urls.append(f"https://images.psmcdn.net/teamskeet/{code}/{ps}/shared/hi.jpg")
            cdn_urls.append(f"https://images.psmcdn.net/teamskeet/{code}/{ps}/shared/med.jpg")
    # Nubiles network
    for s in (u, h.replace("-", "_"), h):
        cdn_urls.append(f"https://images.nubiles-porn.com/videos/{s}/samples/cover1280.jpg")

    def check(url: str):
        sc = score_cover(url)
        if sc < 12:
            return None
        if is_image_url(url):
            return url, sc
        return None

    with ThreadPoolExecutor(max_workers=10) as ex:
        futs = {ex.submit(check, url): url for url in cdn_urls[:30]}
        for fut in as_completed(futs):
            try:
                res = fut.result()
            except Exception:
                res = None
            if not res:
                continue
            url, sc = res
            result["sourcesTried"].append({"url": url, "score": sc, "via": "CDN pattern"})
            if sc > result["coverScore"]:
                result["coverUrl"] = url
                result["coverScore"] = sc
                result["coverVerified"] = True
                result["confidence"] = "high" if sc >= 18 else "medium"
                result["notes"] = "Cover via TeamSkeet / Nubiles CDN pattern"
                if sc >= 22:
                    break

    if not result["coverUrl"]:
        result["confidence"] = "low"
        result["notes"] = (
            "No promotional cover found. Try the official scene URL or include studio name "
            "(Family Strokes / Bratty Sis)."
        )
    elif result["coverScore"] >= 18:
        result["confidence"] = "high"
    elif result["coverScore"] >= 12:
        result["confidence"] = "medium"

    result["sourcesTried"] = result["sourcesTried"][:20]
    if not result["officialUrl"] and h:
        result["officialUrl"] = f"https://www.familystrokes.com/movies/{h}"
    return result


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print(f"[{self.log_date_time_string()}] {args[0] if args else fmt}")

    def send_json(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        if self.path.startswith("/api/search"):
            qs = parse_qs(urlparse(self.path).query)
            q = qs.get("q", [""])[0]
            if not q:
                return self.send_json({"error": "missing q"}, 400)
            try:
                return self.send_json(identify(q))
            except Exception as e:
                import traceback

                traceback.print_exc()
                return self.send_json({"error": str(e), "confidence": "low"}, 500)

        path = self.path.split("?")[0]
        if path in ("/", "/index.html"):
            path = "/index.html"
        file_path = STATIC / path.lstrip("/")
        try:
            data = file_path.read_bytes()
            ctype = "text/html; charset=utf-8"
            if path.endswith(".js"):
                ctype = "application/javascript; charset=utf-8"
            elif path.endswith(".css"):
                ctype = "text/css; charset=utf-8"
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except FileNotFoundError:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"Not found")

    def do_POST(self):
        if self.path == "/api/search":
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length)
            try:
                q = json.loads(body.decode("utf-8")).get("q", "")
            except Exception:
                q = ""
            if not q:
                return self.send_json({"error": "missing q"}, 400)
            try:
                return self.send_json(identify(q))
            except Exception as e:
                return self.send_json({"error": str(e)}, 500)
        self.send_response(404)
        self.end_headers()


if __name__ == "__main__":
    print(f"أصل (Asl) Grok project → http://127.0.0.1:{PORT}")
    print("Examples: Family Vacation!!! Family Strokes | Prom Night Pussy Practice")
    HTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
