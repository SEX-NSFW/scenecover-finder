# أصل (Asl) — Grok Project

من الاسم إلى الغلاف الرسمي · Family Strokes / TeamSkeet

## التشغيل

```bash
pip install requests beautifulsoup4
python3 server.py
```

افتح: http://127.0.0.1:8765

## أمثلة

- `Prom Night Pussy Practice`
- `Family Vacation!!! Family Strokes`
- `It Just Slipped In S2:E8 Bratty Sis`
- رابط مباشر: `https://www.familystrokes.com/movies/prom-night-pussy-practice`

## الهيكل

```
asl-grok/
├── server.py          # محرك البحث + HTTP
├── static/
│   ├── index.html     # الواجهة
│   └── app.js         # i18n + استدعاء API
└── README.md
```

## ملاحظة

يحتاج سيرفر Python (لا يعمل على GitHub Pages الثابت).
للنشر: Railway / Render / VPS.
